import { Typography } from '@mui/material'
import React from 'react'

const About = () => {
    return (
        <div>
            <Typography variant='h3'>About</Typography>
        </div>
    )
}

export default About

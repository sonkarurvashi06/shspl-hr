import { Typography } from '@mui/material'
import React from 'react'

const Rpo = () => {
    return (
        <div>
            <Typography variant='h3'>Rpo</Typography>
        </div>
    )
}

export default Rpo

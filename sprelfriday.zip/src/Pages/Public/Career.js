import { Typography } from '@mui/material'
import React from 'react'

const Career = () => {
    return (
        <div>
            <Typography variant='h3'>Career</Typography>
        </div>
    )
}

export default Career

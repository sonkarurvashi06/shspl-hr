import { Typography } from '@mui/material'
import React from 'react'

const Services = () => {
    return (
        <div>
            <Typography variant='h3'>Services</Typography>
        </div>
    )
}

export default Services
